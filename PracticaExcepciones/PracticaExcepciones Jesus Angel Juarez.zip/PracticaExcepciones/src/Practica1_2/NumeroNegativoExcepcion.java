package Practica1_2;

public class NumeroNegativoExcepcion extends Exception {
    public NumeroNegativoExcepcion() {
    }

    public NumeroNegativoExcepcion(String s) {
        super(s);
    }
}
